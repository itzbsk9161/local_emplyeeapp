package com.example.local_emplyeeapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
